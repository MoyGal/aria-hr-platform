import React from 'react';
import { UserButton, useUser } from '@clerk/nextjs';
import Link from 'next/link';
import Dashboard3D from '@/components/Dashboard3D';

export default function Dashboard() {
  const { user } = useUser();

  // HR metrics data
  const metricsData = {
    candidates: 1247,
    interviews: 432,
    positions: 89,
    successRate: 94.2
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">A</span>
                </div>
                <span className="text-white text-xl font-bold">ARIA</span>
              </Link>
              <span className="text-purple-300 text-sm">Dashboard</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-purple-200 text-sm">
                Bienvenido, {user?.firstName}
              </span>
              <UserButton afterSignOutUrl="/" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Candidatos Activos</p>
                <p className="text-white text-2xl font-bold">{metricsData.candidates.toLocaleString()}</p>
                <p className="text-green-400 text-xs">+12% este mes</p>
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Entrevistas IA</p>
                <p className="text-white text-2xl font-bold">{metricsData.interviews}</p>
                <p className="text-green-400 text-xs">+8% este mes</p>
              </div>
              <div className="w-12 h-12 bg-pink-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Posiciones Abiertas</p>
                <p className="text-white text-2xl font-bold">{metricsData.positions}</p>
                <p className="text-yellow-400 text-xs">+3 nuevas</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2-2v2m8 0V6a2 2 0 012 2v6a2 2 0 01-2 2H8a2 2 0 01-2-2V8a2 2 0 012-2V6" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Tasa de Éxito</p>
                <p className="text-white text-2xl font-bold">{metricsData.successRate}%</p>
                <p className="text-green-400 text-xs">+2.1% este mes</p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
              <h3 className="text-white text-lg font-semibold mb-4">Acciones Rápidas</h3>
              <div className="space-y-3">
                <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white p-3 rounded-lg transition-all flex items-center space-x-3">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  <span>Nueva Posición</span>
                </button>
                
                <button className="w-full bg-white/10 hover:bg-white/20 text-white p-3 rounded-lg transition-all flex items-center space-x-3">
cat > src/components/Dashboard3D.tsx << 'EOF'
'use client'

import { useEffect, useRef } from 'react'

interface Dashboard3DProps {
  candidatesData: number;
  interviewsData: number;
  positionsData: number;
  successRate: number;
}

export default function Dashboard3D({ candidatesData, interviewsData, positionsData, successRate }: Dashboard3DProps) {
  const mountRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    console.log('Dashboard3D mounting with data:', { candidatesData, interviewsData, positionsData, successRate })
  }, [candidatesData, interviewsData, positionsData, successRate])

  return (
    <div className="relative h-64 bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-lg border border-white/10 overflow-hidden">
      <div ref={mountRef} className="w-full h-full flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mx-auto mb-4 animate-pulse">
            <span className="text-white text-2xl">3D</span>
          </div>
          <p className="text-white font-semibold">Dashboard 3D Cargando...</p>
          <p className="text-purple-300 text-sm">Datos: {candidatesData} candidatos</p>
        </div>
      </div>
    </div>
  )
}
EOF
