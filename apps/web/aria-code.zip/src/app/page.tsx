'use client'

import Link from 'next/link'

export default function HomePage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-purple-700 via-indigo-600 to-blue-500 text-white">
      <h1 className="text-6xl font-bold mb-6">ARIA</h1>
      <p className="text-xl mb-8 max-w-xl text-center">
        AI‑Powered Revolutionary Intelligence Architecture. Transform your hiring process with advanced AI, real‑time insights, and revolutionary interview experiences.
      </p>
      <div className="flex gap-6">
        <Link href="/sign-up">
          <button className="
            relative inline-flex items-center justify-center
            px-8 py-4 rounded-xl
            bg-gradient-to-r from-blue-600 to-purple-600
            text-white font-semibold
            shadow-[0_6px_0_rgba(0,0,0,0.25)]
            transition-all duration-300
            transform hover:-translate-y-1 hover:shadow-[0_8px_0_rgba(0,0,0,0.25)]
            active:translate-y-0 active:shadow-[0_4px_0_rgba(0,0,0,0.25)]
          ">
            Get Started
          </button>
        </Link>
        <Link href="/sign-in">
          <button className="
            relative inline-flex items-center justify-center
            px-8 py-4 rounded-xl
            border border-white
            text-white font-semibold
            bg-transparent
            shadow-[0_6px_0_rgba(0,0,0,0.25)]
            transition-all duration-300
            transform hover:-translate-y-1 hover:bg-white hover:text-blue-700 hover:shadow-[0_8px_0_rgba(0,0,0,0.25)]
            active:translate-y-0 active:shadow-[0_4px_0_rgba(0,0,0,0.25)]
          ">
            Learn More
          </button>
        </Link>
      </div>
    </main>
  )
}
