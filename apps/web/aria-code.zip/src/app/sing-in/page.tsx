// apps/web/src/app/sign-in/page.tsx
'use client'

import { SignIn } from '@clerk/nextjs'

export default function SignInPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">ARIA</h1>
          <p className="text-purple-200">Accede a la revolución HR</p>
        </div>
        <SignIn
          afterSignInUrl="/dashboard"
          redirectUrl="/dashboard"
          appearance={{
            variables: {
              colorPrimary: '#8b5cf6',
              colorBackground: 'rgba(255, 255, 255, 0.95)',
              colorInputBackground: 'rgba(255, 255, 255, 0.9)',
              borderRadius: '0.5rem'
            }
          }}
        />
      </div>
    </div>
  )
}
