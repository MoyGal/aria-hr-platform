'use client'

import { useClerk } from '@clerk/nextjs'
import { useRouter } from 'next/navigation'

export default function LogoutButton() {
  const { signOut } = useClerk()
  const router = useRouter()

  const handleLogout = async () => {
    try {
      await signOut({ redirectUrl: '/' })
    } catch (err) {
      console.error('Error al cerrar sesión:', err)
    }
  }

  return (
    <button
      onClick={handleLogout}
      className="bg-gradient-to-r from-red-500 to-pink-500 text-white px-6 py-3 rounded-xl hover:from-red-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg font-medium"
    >
      Logout
    </button>
  )
}
